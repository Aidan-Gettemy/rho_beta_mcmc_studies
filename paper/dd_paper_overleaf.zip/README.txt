DD paper outline for Overleaf
- Upload this zip (New Project > Upload Project). Main file: main.tex, compiler pdfLaTeX (TeX Live 2023 or newer).
- figures/ holds the four PNGs used; tab_*.tex are generated tables (see paper/make_tables.py in the repository, rerun it to refresh them from master_table.csv).
- Annotation commands (defined at the top of main.tex): \todo{..} red; \addfig{..} bold purple "Let's add this figure/table/result here"; \addmath{..} bold teal "Let's add more mathematical detail here"; \needsource{..} bold orange "Source needed". Set \annotationsfalse to hide the last three.
